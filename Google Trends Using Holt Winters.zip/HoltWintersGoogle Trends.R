#import and read the dataset
modi<-read.csv("clipboard",sep='\t',header=T)
#rename the column
library(dplyr)
library(tidyverse)
library(tseries)
library(forecast)
names(modi)
#rename the column
modi<-modi %>% 
  rename(nm = narendra.modi...Worldwide.)
summary(modi)
#change week column data type
library(lubridate)
modi$Week<-parse_date_time(modi$Week, orders = c("%d/%m/%Y","%d-%m-%Y"))
modi$Week<-as.Date(modi$Week)
str(modi$Week)
# since we are trying to forecast on "nm", we need to convert it into a time series variable
?ts
y<-ts(data = modi$nm,
      frequency = 52,
      start = c(2018,31))
# frequency will be 52 as it as weekly data and 12.08.18 falls in the 32nd week of the year
plot.ts(y)
ggseasonplot(y , main = "Seasonality Graph")
ggseasonplot(y , polar = T)

#split the data into train and test for validation of the model and predicting the accuracy of model
?window
training<-window(x = y , end = c(2022,52)) # x will be your time series object. Training will contain data from 
# the start date till the 52nd week of 2022
testing<-window(x= y, start = c(2023,1)) # testing will contain data from 1st week of 2023 till the end

?HoltWinters
model<-HoltWinters(training, seasonal = "multiplicative")

#predictions
predictions<-forecast(model, h=length(testing)) #testing stands for the period of test data
predictions
plot(predictions)

#accuracy
accuracy(predictions$mean,testing)
#RMSE is 10.17 and MAPE is 82.10 i.e accuracy is (100-82.10) = 17.9%

predictions$mean #shows the absolute mean values for each week starting from the test data date

################################## using multiplicative model
model1<-HoltWinters(training, seasonal = "additive")

#predictions
predictions1<-forecast(model1, h=length(testing))
predictions1

#accuracy
accuracy(predictions1$mean,testing)
#RMSE is 8.79 , MAPE is 69.52 i.e accuracy is (100-69.52) = 30.48%
predictions1$mean

# RMSE is higher in multiplicative model so we will stick with multiplicative